# Discord Bot

## Overview
This is a Discord bot project that runs on Replit with a Flask webserver to keep it alive. The bot is restricted to a specific Discord channel (channel ID: 1442474461247963136) on a specific server (guild ID: 1436101095276675174) and includes a simple `!hello` command.

## Project Structure
- `main.py` - Main Discord bot code with commands and event handlers
- `webserver.py` - Flask webserver running on port 5000 to keep the bot alive
- `requirements.txt` - Python dependencies (discord.py, flask)

## Setup Instructions

### 1. Discord Bot Token
The bot requires a `DISCORD_BOT_TOKEN` secret to be configured in Replit Secrets. Get your token from:
https://discord.com/developers/applications/

### 2. **IMPORTANT: Enable Privileged Intents**
You MUST enable the following in the Discord Developer Portal:
1. Go to https://discord.com/developers/applications/
2. Select your application/bot
3. Go to the "Bot" section
4. Scroll down to "Privileged Gateway Intents"
5. **Enable "MESSAGE CONTENT INTENT"**
6. **Enable "SERVER MEMBERS INTENT"**
7. Click "Save Changes"

Without these, the bot will crash with a `PrivilegedIntentsRequired` error.

### 3. Bot Permissions
When inviting the bot to your server, make sure it has:
- Send Messages
- Read Message History
- Use Slash Commands (if using slash commands in future)

## Current State
- **Status**: Configured and ready to run
- **Webserver**: Running on port 5000 (provides a health check endpoint)
- **Bot**: Will run once Message Content Intent is enabled in Discord Developer Portal

## Features
- **Channel-restricted**: Bot only responds to commands in the allowed channel (1442474461247963136) on the allowed server (1436101095276675174)
- **`!hello` command**: Responds with a greeting mentioning the user
- **`!add` command**: Adds a user to the organization message with their role
  - Usage: `!add <Discord-Name> <Rolle>`
  - Available roles: ceo, sv, dk, opl, kd, tl, ltf, tf, lf, aw, rk, lv
  - Updates message 1442212690880626953 in channel 1436384612476649493
- **Keep-alive webserver**: Flask server on port 5000 keeps the bot running

## Recent Changes (Nov 24, 2025)
- Imported from GitHub
- Fixed requirements file naming (requierments.txt → requirements.txt)
- Updated webserver to use port 5000 (Replit standard)
- Fixed execution order (webserver starts before bot)
- Added Python .gitignore
- Configured workflow for automatic startup
- Added channel restriction: Bot now only responds in channel 1442474461247963136
- Added `!add` command for managing organization roles in message 1442212690880626953
- Enabled Members Intent for accessing guild member list

## Known Issues
- Bot will crash on startup if Message Content Intent is not enabled in Discord Developer Portal
- User must enable this privileged intent manually

## Next Steps
1. Enable Message Content Intent in Discord Developer Portal
2. Restart the workflow to test the bot
3. Consider adding more commands
4. Consider adding error handling for missing intents
